const { Telegraf, Markup } = require('telegraf');
const fs = require('fs');
const config = require('./config');
const { triggerGitHubBuild, checkBuildStatus } = require('./build-handler');

const bot = new Telegraf(config.BOT_TOKEN);
let premiumUsers = new Set();
let buildQueue = [];
let activeBuilds = 0;

// ========== LOAD DATABASE ==========
function loadPremium() {
  try {
    if (fs.existsSync(config.PREM_DB)) {
      const data = JSON.parse(fs.readFileSync(config.PREM_DB, 'utf8'));
      premiumUsers = new Set(data);
    }
  } catch(e) {}
}

function savePremium() {
  fs.writeFileSync(config.PREM_DB, JSON.stringify([...premiumUsers], null, 2));
}

function loadQueue() {
  try {
    if (fs.existsSync('./queue.json')) {
      buildQueue = JSON.parse(fs.readFileSync('./queue.json', 'utf8'));
    }
  } catch(e) {}
}

function saveQueue() {
  fs.writeFileSync('./queue.json', JSON.stringify(buildQueue, null, 2));
}

loadPremium();
loadQueue();

const isPremium = (id) => premiumUsers.has(id.toString());
const isOwner = (id) => id === config.OWNER_ID;

// ========== UPDATE WORKER STATUS ==========
function updateWorkerStatus(workerName, status, user, time, eta) {
  if (config.workers[workerName]) {
    config.workers[workerName].status = status;
    config.workers[workerName].currentUser = user;
    config.workers[workerName].timeElapsed = time;
    config.workers[workerName].eta = eta;
  }
}

// ========== PROCESS QUEUE ==========
async function processQueue() {
  if (activeBuilds >= config.maxConcurrent) return;
  if (buildQueue.length === 0) return;
  
  const nextJob = buildQueue.shift();
  saveQueue();
  activeBuilds++;
  
  const workerName = activeBuilds === 1 ? 'worker-1' : 'worker-2';
  updateWorkerStatus(workerName, 'busy', nextJob.user, '0m 0s', config.estimatedTime);
  
  await bot.telegram.sendMessage(nextJob.userId, 
    `🚀 *Build dimulai!*\n\n📦 Proyek: ${nextJob.projectName}\n🖥️ Worker: ${workerName}\n⏱️ Estimasi: ${config.estimatedTime}\n\nStatus akan diupdate...`,
    { parse_mode: 'Markdown' }
  );
  
  // Trigger build via GitHub Actions
  const result = await triggerGitHubBuild(nextJob);
  
  activeBuilds--;
  updateWorkerStatus(workerName, 'idle', null, null, null);
  
  if (result.success) {
    config.stats.success++;
    await bot.telegram.sendMessage(nextJob.userId,
      `✅ *Build BERHASIL!*\n\n📦 ${nextJob.projectName}\n\n📱 *Download APK:* ${result.downloadUrl}\n\nKlik link di atas untuk download APK.`,
      { parse_mode: 'Markdown' }
    );
  } else {
    config.stats.failed++;
    await bot.telegram.sendMessage(nextJob.userId,
      `❌ *Build GAGAL!*\n\n📦 ${nextJob.projectName}\n❌ Error: ${result.error}\n\nSilakan coba lagi atau hubungi ${config.ownerContact}`,
      { parse_mode: 'Markdown' }
    );
  }
  
  saveStats();
  processQueue();
}

function saveStats() {
  fs.writeFileSync('./stats.json', JSON.stringify({ 
    success: config.stats.success, 
    failed: config.stats.failed 
  }, null, 2));
}

// ========== MENU ==========
const mainMenu = () => Markup.inlineKeyboard([
  [Markup.button.callback('📦 Build APK', 'build_menu')],
  [Markup.button.callback('📊 Status Build', 'status_menu')],
  [Markup.button.callback('⚙️ Perintah', 'commands_menu')],
  [Markup.button.callback('👑 Owner', 'owner_menu')],
  [Markup.button.callback('ℹ️ Information', 'info_menu')]
]);

bot.start((ctx) => {
  ctx.reply(`${config.BOT_NAME} v${config.VERSION}\n📊 ${config.stats.monthlyUsers} monthly users\n\n${config.messages.welcome}`, mainMenu());
});

bot.action('build_menu', (ctx) => {
  ctx.answerCbQuery();
  ctx.editMessageText('*Silakan pilih mode build:*', {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('📱 Build Flutter', 'build_flutter')],
      [Markup.button.callback('🌐 Build WebView', 'build_webview')],
      [Markup.button.callback('🤖 Build Android Native', 'build_native')],
      [Markup.button.callback('📊 Lihat Antrian', 'view_queue')],
      [Markup.button.callback('🔙 Kembali', 'back_main')]
    ])
  });
});

bot.action('build_flutter', (ctx) => {
  ctx.answerCbQuery();
  ctx.editMessageText('📱 *Build Flutter APK*\n\nLangkah 1/3: Kirimkan *URL GitHub repository* Flutter project.\n\nContoh: `https://github.com/username/flutter-app.git`', {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([Markup.button.callback('🔙 Kembali', 'build_menu')])
  });
  ctx.session = { state: 'waiting_repo_url', type: 'flutter' };
});

bot.action('build_webview', (ctx) => {
  ctx.answerCbQuery();
  ctx.editMessageText('🌐 *Build WebView APK*\n\nLangkah 1/3: Kirimkan *URL website* yang ingin dijadikan APK.\n\nContoh: `https://example.com`', {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([Markup.button.callback('🔙 Kembali', 'build_menu')])
  });
  ctx.session = { state: 'waiting_webview_url', type: 'webview' };
});

bot.action('build_native', (ctx) => {
  ctx.answerCbQuery();
  ctx.editMessageText('🤖 *Build Android Native APK*\n\nLangkah 1/3: Kirimkan *URL GitHub repository* Android project.\n\nContoh: `https://github.com/username/android-app.git`', {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([Markup.button.callback('🔙 Kembali', 'build_menu')])
  });
  ctx.session = { state: 'waiting_repo_url', type: 'android' };
});

bot.action('view_queue', (ctx) => {
  if (buildQueue.length === 0 && activeBuilds === 0) {
    ctx.editMessageText('📭 *Antrian kosong*', {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([Markup.button.callback('🔙 Kembali', 'build_menu')])
    });
    return;
  }
  
  let text = `📋 *QUEUE SYSTEM*\n\n🔄 Active: ${activeBuilds}/${config.maxConcurrent}\n⏳ Queue: ${buildQueue.length}\n\n`;
  if (activeBuilds > 0) {
    text += `*Sedang Build:*\n`;
    for (let [name, worker] of Object.entries(config.workers)) {
      if (worker.status === 'busy') {
        text += `• ${worker.currentUser} (${worker.timeElapsed} / ${worker.eta})\n`;
      }
    }
  }
  if (buildQueue.length > 0) {
    text += `\n*Antrian:*\n`;
    buildQueue.slice(0, 5).forEach((job, i) => {
      text += `${i+1}. ${job.user} - ${job.projectName}\n`;
    });
  }
  
  ctx.editMessageText(text, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([Markup.button.callback('🔄 Refresh', 'view_queue'), Markup.button.callback('🔙 Kembali', 'build_menu')])
  });
});

bot.action('status_menu', (ctx) => {
  let text = `📊 *Status Worker & Antrian*\n\n`;
  text += `• Worker 1 – ${config.workers['worker-1'].status === 'busy' ? '🔴 Sedang Build' : '🟢 Siap'}\n`;
  if (config.workers['worker-1'].currentUser) {
    text += `  👤 ${config.workers['worker-1'].currentUser} ⏱️ ${config.workers['worker-1'].timeElapsed}\n`;
  }
  text += `• Worker 2 – ${config.workers['worker-2'].status === 'busy' ? '🔴 Sedang Build' : '🟢 Siap'}\n\n`;
  text += `📋 Antrian: ${buildQueue.length}\n`;
  text += `📊 Statistik: ${config.stats.success} ✅ | ${config.stats.failed} ❌\n`;
  
  ctx.answerCbQuery();
  ctx.editMessageText(text, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('🔄 Refresh', 'status_menu')],
      [Markup.button.callback('🔙 Kembali', 'back_main')]
    ])
  });
});

bot.action('commands_menu', (ctx) => {
  ctx.answerCbQuery();
  ctx.editMessageText('📟 *Perintah*\n\n/start — Menu utama\n/done — Konfirmasi transaksi\n/queue — Lihat antrian\n/cancel — Batalkan build\n/stats — Statistik (owner)', {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([Markup.button.callback('🔙 Kembali', 'back_main')])
  });
});

bot.action('info_menu', (ctx) => {
  ctx.answerCbQuery();
  ctx.editMessageText(`ℹ️ *${config.BOT_NAME}*\n\nBuild APK from:\n✅ Flutter\n✅ WebView\n✅ Android Native\n\n⚡ Queue System: Aktif\n🖥️ Platform: GitHub Actions\n📊 Users: ${config.stats.monthlyUsers}/bulan`, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('💰 Harga', 'price_menu')],
      [Markup.button.callback('🔙 Kembali', 'back_main')]
    ])
  });
});

bot.action('price_menu', (ctx) => {
  ctx.editMessageText(`*PRICE UPGRADE AKSES*\n\n*1 Week:*\n• Perpanjang Mingguan: 5K\n• Up Ke 1 Bulan: 10K\n• Up Ke Perma: 15K\n• Up Ke Ress: 20K\n\n*1 Month:*\n• Up Ke Perma: 10K\n• Up Ke Ress: 15K\n\n*Perma:*\n• Up Ke Ress: 10K\n\nMINAT DM ${config.ownerContact}`, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [Markup.button.url('💬 DM Owner', `https://t.me/${config.ownerContact.replace('@', '')}`)],
      [Markup.button.callback('🔙 Kembali', 'info_menu')]
    ])
  });
});

bot.action('owner_menu', (ctx) => {
  if (!isOwner(ctx.from.id)) {
    return ctx.answerCbQuery('❌ Hanya owner!', true);
  }
  ctx.editMessageText('👑 *Owner Menu*\n\n/addprem @user\n/removeprem @user\n/listprem\n/broadcast pesan\n/clearqueue\n/stats', {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([Markup.button.callback('🔙 Kembali', 'back_main')])
  });
});

bot.action('back_main', (ctx) => {
  ctx.answerCbQuery();
  ctx.editMessageText(`${config.BOT_NAME} v${config.VERSION}\n📊 ${config.stats.monthlyUsers} monthly users\n\n${config.messages.welcome}`, mainMenu());
});

// ========== HANDLE TEXT INPUT ==========
bot.on('text', async (ctx) => {
  const state = ctx.session?.state;
  
  if (state === 'waiting_repo_url') {
    const repoUrl = ctx.message.text;
    ctx.reply('✅ URL diterima!\n\nLangkah 2/3: Kirimkan *nama proyek* untuk APK ini.', { parse_mode: 'Markdown' });
    ctx.session = { state: 'waiting_name', repoUrl, type: ctx.session.type };
    return;
  }
  
  if (state === 'waiting_webview_url') {
    const webUrl = ctx.message.text;
    if (!webUrl.startsWith('http')) {
      return ctx.reply('❌ URL harus diawali http:// atau https://');
    }
    ctx.reply('✅ URL diterima!\n\nLangkah 2/3: Kirimkan *nama proyek* untuk APK ini.', { parse_mode: 'Markdown' });
    ctx.session = { state: 'waiting_name', webUrl, type: ctx.session.type };
    return;
  }
  
  if (state === 'waiting_name') {
    const projectName = ctx.message.text;
    const userId = ctx.from.id;
    const username = ctx.from.username || ctx.from.first_name;
    
    const job = {
      id: Date.now(),
      userId: userId,
      user: `@${username}`,
      projectName: projectName,
      type: ctx.session.type,
      repoUrl: ctx.session.repoUrl,
      webUrl: ctx.session.webUrl,
      timestamp: new Date().toISOString()
    };
    
    buildQueue.push(job);
    saveQueue();
    
    ctx.reply(`✅ *${projectName}* ditambahkan ke antrian!\n\n📋 Posisi: ${buildQueue.length}\n\nKamu akan mendapat notifikasi saat build dimulai dan selesai.`, { parse_mode: 'Markdown' });
    
    delete ctx.session;
    processQueue();
  }
});

// ========== /done COMMAND ==========
bot.command('done', async (ctx) => {
  const args = ctx.message.text.replace('/done', '').trim().split(',');
  if (args.length < 2) {
    return ctx.reply('❌ Gunakan: /done nama item, harga, [payment]\n\nContoh: /done AF || Ubet Hong mod. X9 STR, 50000, DANA');
  }
  
  const itemName = args[0].trim();
  const price = args[1].trim();
  const payment = args[2]?.trim() || 'TIDAK DITENTUKAN';
  
  let photoUrl = null;
  if (ctx.message.reply_to_message?.photo) {
    photoUrl = ctx.message.reply_to_message.photo[ctx.message.reply_to_message.photo.length - 1].file_id;
  }
  
  const message = `✅ *Transaksi Dicatat!*\n\n📦 Item: ${itemName}\n💰 Harga: ${price}\n💳 Payment: ${payment}\n👤 User: ${ctx.from.first_name}\n🕐 ${new Date().toLocaleString('id-ID')}`;
  
  const ownerMsg = `🔔 *TRANSAKSI BARU*\n\n📦 ${itemName}\n💰 ${price}\n💳 ${payment}\n👤 ${ctx.from.first_name} (ID: ${ctx.from.id})\n🔗 @${ctx.from.username || 'no_username'}`;
  
  if (photoUrl) {
    await ctx.replyWithPhoto(photoUrl, { caption: message, parse_mode: 'Markdown' });
    await bot.telegram.sendPhoto(config.OWNER_ID, photoUrl, { caption: ownerMsg, parse_mode: 'Markdown' });
  } else {
    await ctx.reply(message, { parse_mode: 'Markdown' });
    await bot.telegram.sendMessage(config.OWNER_ID, ownerMsg, { parse_mode: 'Markdown' });
  }
});

// ========== OWNER COMMANDS ==========
bot.command('addprem', (ctx) => {
  if (!isOwner(ctx.from.id)) return;
  const mention = ctx.message.text.split(' ')[1];
  if (!mention) return ctx.reply('Gunakan: /addprem @username');
  premiumUsers.add(mention.replace('@', ''));
  savePremium();
  ctx.reply(`✅ ${mention} ditambahkan ke premium.`);
});

bot.command('removeprem', (ctx) => {
  if (!isOwner(ctx.from.id)) return;
  const mention = ctx.message.text.split(' ')[1];
  if (!mention) return ctx.reply('Gunakan: /removeprem @username');
  premiumUsers.delete(mention.replace('@', ''));
  savePremium();
  ctx.reply(`❌ ${mention} dihapus dari premium.`);
});

bot.command('listprem', (ctx) => {
  if (!isOwner(ctx.from.id)) return;
  const list = [...premiumUsers].map(u => `@${u}`).join('\n') || 'Kosong';
  ctx.reply(`📋 Premium Users:\n${list}`);
});

bot.command('clearqueue', (ctx) => {
  if (!isOwner(ctx.from.id)) return;
  buildQueue = [];
  saveQueue();
  ctx.reply('✅ Antrian dibersihkan!');
});

bot.command('queue', (ctx) => {
  if (buildQueue.length === 0) return ctx.reply('📭 Antrian kosong');
  let text = `📋 ANTRIAN:\n`;
  buildQueue.forEach((job, i) => { text += `${i+1}. ${job.user} - ${job.projectName}\n`; });
  ctx.reply(text);
});

bot.command('stats', (ctx) => {
  if (!isOwner(ctx.from.id)) return;
  ctx.reply(`📊 STATISTIK:\n✅ Sukses: ${config.stats.success}\n❌ Gagal: ${config.stats.failed}\n👥 Premium: ${premiumUsers.size}\n📋 Queue: ${buildQueue.length}`);
});

// ========== LAUNCH ==========
bot.launch();
console.log(`✅ ${config.BOT_NAME} siap! Queue system aktif.`);