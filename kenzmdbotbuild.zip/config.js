// config.js - Web2Apk V2 Gen 1
// Bot Telegram dengan Queue System & GitHub Actions

module.exports = {
  // ========== TELEGRAM CONFIG ==========
  BOT_TOKEN: 'YOUR_BOT_TOKEN_HERE',     // Ganti dengan token bot Tuan
  OWNER_ID: 123456789,                  // Ganti dengan ID Telegram Tuan Kenzmd
  
  // ========== BOT INFO ==========
  BOT_NAME: 'Web2Apk V2 Gen 1',
  VERSION: '2.0',
  PREM_DB: './premium_users.json',
  
  // ========== GITHUB CONFIG ==========
  GITHUB: {
    REPO_OWNER: 'kenzdevgtg_boop',     // Username GitHub Tuan
    REPO_NAME: 'Build-apl',            // Nama repository
    GITHUB_TOKEN: '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',  // Personal Access Token
    WORKFLOW_FILE: 'build-apk.yml'
  },
  
  // ========== QUEUE & BUILD ==========
  maxConcurrent: 2,                    // Maksimal build bersamaan
  estimatedTime: '~6m 56s',            // Estimasi waktu build
  buildTimeout: 15,                    // Timeout build (menit)
  
  // ========== WORKER STATUS ==========
  workers: {
    'worker-1': {
      status: 'idle',
      currentUser: null,
      timeElapsed: null,
      eta: null
    },
    'worker-2': {
      status: 'idle',
      currentUser: null,
      timeElapsed: null,
      eta: null
    }
  },
  
  // ========== STATISTIK ==========
  stats: {
    success: 13,
    failed: 4,
    monthlyUsers: 824
  },
  
  // ========== HARGA UPGRADE ==========
  prices: {
    weekly: { name: 'Perpanjang Mingguan', price: 5000, duration: 7 },
    month: { name: 'Up Ke 1 Bulan', price: 10000, duration: 30 },
    perma: { name: 'Up Ke Perma', price: 15000, duration: 36500 },
    ress: { name: 'Up Ke Ress', price: 20000, duration: 36500 }
  },
  
  // ========== KONTAK OWNER ==========
  ownerContact: '@LordDzik',
  ownerLink: 'https://t.me/LordDzik',
  
  // ========== PESAN ==========
  messages: {
    welcome: 'Silakan pilih menu di bawah:',
    noAccess: 'Fitur ini memerlukan akses. Hubungi admin untuk mendapatkan akses.',
    premiumOnly: 'Fitur ini hanya untuk user premium.',
    invalidUrl: '⚠️ URL harus diawali http:// atau https://'
  }
};