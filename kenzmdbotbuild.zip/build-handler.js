// build-handler.js - Handler untuk trigger build via GitHub Actions

const config = require('./config');

async function triggerGitHubBuild(job) {
  const { GITHUB } = config;
  
  // Data untuk trigger workflow
  const workflowData = {
    ref: 'main',
    inputs: {
      project_name: job.projectName,
      project_type: job.type,
      repo_url: job.repoUrl || '',
      web_url: job.webUrl || '',
      user_id: job.userId.toString(),
      user_name: job.user
    }
  };
  
  try {
    const response = await fetch(
      `https://api.github.com/repos/${GITHUB.REPO_OWNER}/${GITHUB.REPO_NAME}/actions/workflows/${GITHUB.WORKFLOW_FILE}/dispatches`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${GITHUB.GITHUB_TOKEN}`,
          'Accept': 'application/vnd.github.v3+json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(workflowData)
      }
    );
    
    if (response.ok) {
      // Simulasi download URL (nanti dari artifact GitHub)
      const downloadUrl = `https://github.com/${GITHUB.REPO_OWNER}/${GITHUB.REPO_NAME}/actions/runs/latest`;
      return { success: true, downloadUrl: downloadUrl };
    } else {
      return { success: false, error: `GitHub API error: ${response.status}` };
    }
  } catch (error) {
    return { success: false, error: error.message };
  }
}

async function checkBuildStatus(runId) {
  const { GITHUB } = config;
  
  try {
    const response = await fetch(
      `https://api.github.com/repos/${GITHUB.REPO_OWNER}/${GITHUB.REPO_NAME}/actions/runs/${runId}`,
      {
        headers: {
          'Authorization': `Bearer ${GITHUB.GITHUB_TOKEN}`,
          'Accept': 'application/vnd.github.v3+json'
        }
      }
    );
    
    const data = await response.json();
    return {
      status: data.status,
      conclusion: data.conclusion,
      downloadUrl: `https://github.com/${GITHUB.REPO_OWNER}/${GITHUB.REPO_NAME}/actions/runs/${runId}`
    };
  } catch (error) {
    return { status: 'error', conclusion: null, downloadUrl: null };
  }
}

module.exports = { triggerGitHubBuild, checkBuildStatus };